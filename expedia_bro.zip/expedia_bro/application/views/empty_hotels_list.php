<div class="card card-nav-tabs">
    <div class="card-header card-header-danger">
        <h4 class="card-title"><i class="fa fa-hotel"></i> Hotels List</h4>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-sm-12 col-sm-offest-1">
                <div id="w0" class="text-center" style="font-size:7em; color:Tomato">
                    <i class="fa fa-frown-o"></i><p> No results found.</p>
                </div>
            </div>
        </div>
    </div>
</div>