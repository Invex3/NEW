#### Why you picked the language you did ?

I picked PHP for this project, because I have a good experience on PHP development and it's fair enough for such type of projects.

#### What you wanted to accomplish with application ?

I have to understand the reset API calling methods and what params i can send and understand the API response format so i can represent the data i a good format.

#### What is Your thought process as you built the application ?

- Analyze the reset API to understand the output format and the allowed methods.
- Review the allowed query parameters.
- Review Expedia site to understand how I can represent the data.

#### What you learned in the process. Mention how much (or little) experience you have with the particular language and framework you chose ?

- How to check ready rest API with high level documentaion and try to find out the allowed params for the API to get data as much as I can.
- Understand the data and how its connected so I can represent it in the correct/best format.
- Try to understand the site and how the data represented.
- How to use Heroku.
